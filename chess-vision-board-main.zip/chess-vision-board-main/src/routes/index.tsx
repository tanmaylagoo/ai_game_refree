import { createFileRoute } from "@tanstack/react-router";
import { Toaster } from "react-hot-toast";
import { ChessBoard } from "@/components/chess/ChessBoard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Chess Analysis Board" },
      {
        name: "description",
        content:
          "Premium dark-themed chess analysis board. Play, review, and study positions with FEN, PGN, and move-by-move navigation.",
      },
      { property: "og:title", content: "Chess Analysis Board" },
      {
        property: "og:description",
        content:
          "Analyze any position — drag pieces, browse history, import FEN, export PGN.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_rgba(99,102,241,0.18),_transparent_55%),radial-gradient(ellipse_at_bottom,_rgba(168,85,247,0.15),_transparent_55%)] bg-slate-950 text-slate-100">
      <div className="px-4 py-6 sm:px-8 sm:py-10">
        <ChessBoard />
      </div>
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: "rgba(15,23,42,0.9)",
            color: "#e2e8f0",
            border: "1px solid rgba(255,255,255,0.08)",
            backdropFilter: "blur(12px)",
          },
        }}
      />
    </div>
  );
}
